﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = "Hello World!!";
            int num = 100;
            float num1 = 10.2f;
            char letter = 'A';
            bool logic = true;

        }
    }
}
