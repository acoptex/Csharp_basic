﻿using System;

namespace ConsoleApp2
{
    class Cube
    {
        //variables used
        double length;
        double width;
        double height;

        public void Details()
        {
            Console.Write("Enter length: ");
            length = double.Parse(Console.ReadLine());
            Console.Write("Enter width: ");
            width = double.Parse(Console.ReadLine());
            Console.Write("Enter height: ");
            height = double.Parse(Console.ReadLine());
            Console.WriteLine("");
        }

        public double CalcVolume()
        {
            return length * width * height;
        }

        public void Display()
        {
            //Console.WriteLine("Length: {0}", length);
            //Console.WriteLine("Width: {0}", width);
            //Console.WriteLine("Height: {0}", height);
            //Console.WriteLine("Volume: {0}", CalcVolume());
            Console.WriteLine($"Length: {length}");
            Console.WriteLine($"Width: {width}");
            Console.WriteLine($"Height: {height}");
            Console.WriteLine($"Volume: {CalcVolume()}");
        }
    }
         
    class ExecuteCube
    {

        static void Main(string[] args)
        {
            Cube r = new Cube();
            r.Details();
            r.Display();
            Console.ReadLine();
        }
    }
}